// API Configuration
const API_URL = 'https://script.google.com/macros/s/AKfycbxMNQBfj1UR4smtdH_Cjp9xNghU_fUEiOTd3XSTtYuS31qaFBBuHrtb5xfaISlcsV28Zg/exec';

// DOM Elements
const fetchBtn = document.getElementById('fetchBtn');
const installBtn = document.getElementById('installBtn');
const statusText = document.getElementById('statusText');
const responseDiv = document.getElementById('response');
const installMessage = document.getElementById('installMessage');

// Install prompt
let deferredPrompt;

// Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then((registration) => {
        console.log('Service Worker registered successfully:', registration.scope);
      })
      .catch((error) => {
        console.log('Service Worker registration failed:', error);
      });
  });
}

// Check API status on load
async function checkAPIStatus() {
  try {
    const response = await fetch(API_URL);
    if (response.ok) {
      statusText.textContent = 'Connected';
      statusText.parentElement.classList.add('status-success');
    } else {
      statusText.textContent = 'Error connecting';
      statusText.parentElement.classList.add('status-error');
    }
  } catch (error) {
    statusText.textContent = 'Offline or unreachable';
    statusText.parentElement.classList.add('status-error');
    console.error('API check failed:', error);
  }
}

// Fetch data from API
async function fetchData() {
  const btnText = fetchBtn.querySelector('.btn-text');
  const loader = fetchBtn.querySelector('.loader');
  
  // Show loading state
  btnText.style.display = 'none';
  loader.style.display = 'inline-block';
  fetchBtn.disabled = true;
  
  try {
    const response = await fetch(API_URL);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
      displayResponse(data, 'json');
    } else {
      data = await response.text();
      displayResponse(data, 'text');
    }
    
  } catch (error) {
    displayResponse({ error: error.message }, 'error');
  } finally {
    // Hide loading state
    btnText.style.display = 'inline';
    loader.style.display = 'none';
    fetchBtn.disabled = false;
  }
}

// Display API response
function displayResponse(data, type) {
  responseDiv.innerHTML = '';
  
  const pre = document.createElement('pre');
  const code = document.createElement('code');
  
  if (type === 'error') {
    code.className = 'error';
    code.textContent = `Error: ${data.error}`;
  } else if (type === 'json') {
    code.textContent = JSON.stringify(data, null, 2);
  } else {
    code.textContent = data;
  }
  
  pre.appendChild(code);
  responseDiv.appendChild(pre);
}

// Install button handler
window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent the mini-infobar from appearing
  e.preventDefault();
  // Save the event for later
  deferredPrompt = e;
  // Show the install button
  installBtn.style.display = 'block';
  installMessage.style.display = 'none';
});

installBtn.addEventListener('click', async () => {
  if (!deferredPrompt) {
    return;
  }
  
  // Show the install prompt
  deferredPrompt.prompt();
  
  // Wait for the user's response
  const { outcome } = await deferredPrompt.userChoice;
  console.log(`User response to install prompt: ${outcome}`);
  
  // Clear the deferredPrompt
  deferredPrompt = null;
  installBtn.style.display = 'none';
  installMessage.textContent = outcome === 'accepted' ? 'App installed successfully!' : 'App can be installed from browser menu';
  installMessage.style.display = 'block';
});

// Handle app installed
window.addEventListener('appinstalled', () => {
  console.log('PWA was installed');
  installBtn.style.display = 'none';
  installMessage.textContent = 'App installed successfully!';
  installMessage.style.display = 'block';
});

// Event listeners
fetchBtn.addEventListener('click', fetchData);

// Initialize
checkAPIStatus();

// Check for updates
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.ready.then((registration) => {
    registration.update();
  });
}
